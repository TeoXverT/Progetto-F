package com.github.lgooddatepicker.zinternaltools;

import com.github.lgooddatepicker.datepicker.DatePicker;
import com.github.lgooddatepicker.datetimepicker.DateTimePicker;
import com.github.lgooddatepicker.timepicker.TimePicker;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * DateTimeChangeEvent, An instance of this event class is passed to each registered
 * DateTimeChangeListener, whenever the date or the time in a DateTimePicker has changed.
 *
 * Note that this class will always contain either one dateChangeEvent, or one timeChangeEvent, but
 * never both events at the same time.
 */
public class DateTimeChangeEvent {

    /**
     * Constructor.
     */
    public DateTimeChangeEvent(DateTimePicker source, DatePicker datePicker, TimePicker timePicker,
            DateChangeEvent dateChangeEvent, TimeChangeEvent timeChangeEvent) {
        this.source = source;
        this.datePicker = datePicker;
        this.timePicker = timePicker;
        this.dateChangeEvent = dateChangeEvent;
        this.timeChangeEvent = timeChangeEvent;
    }

    /**
     * source, This is the DateTimePicker that generated the event.
     */
    private final DateTimePicker source;

    /**
     * datePicker, This is a reference to the date picker component of the DateTimePicker.
     */
    private final DatePicker datePicker;

    /**
     * timePicker, This is a reference to the time picker component of the DateTimePicker.
     */
    private final TimePicker timePicker;

    /**
     * dateChangeEvent, If the date changed, then this contains the date change event. Otherwise
     * this contains null.
     */
    private final DateChangeEvent dateChangeEvent;

    /**
     * timeChangeEvent, If the time changed, then this contains the time change event. Otherwise
     * this contains null.
     */
    private final TimeChangeEvent timeChangeEvent;

    /**
     * getSource, Returns the DateTimePicker that generated the event.
     */
    public DateTimePicker getSource() {
        return source;
    }

    /**
     * getDatePicker, Returns a reference to the date picker component of the DateTimePicker.
     */
    public DatePicker getDatePicker() {
        return datePicker;
    }

    /**
     * getTimePicker, Returns a reference to the time picker component of the DateTimePicker.
     */
    public TimePicker getTimePicker() {
        return timePicker;
    }

    /**
     * getDateChangeEvent, If the date changed, then this returns the date change event. Otherwise
     * this returns null.
     */
    public DateChangeEvent getDateChangeEvent() {
        return dateChangeEvent;
    }

    /**
     * getTimeChangeEvent, If the time changed, then this returns the time change event. Otherwise
     * this returns null.
     */
    public TimeChangeEvent getTimeChangeEvent() {
        return timeChangeEvent;
    }

    /**
     * getNewDateTime, This returns the new LocalDateTime value from the DateTimePicker, as it would
     * be reported by getSource().getDateTime().
     *
     * For additional details, see DateTimePicker.getDateTime().
     */
    public LocalDateTime getNewDateTime() {
        return getSource().getDateTime();
    }

    /**
     * getNewDateTimeAndAllowEmptyTimes, This returns the new LocalDateTime value from the
     * DateTimePicker, as it would be reported by getSource().getDateTimeAndAllowEmptyTimes().
     *
     * For additional details, see DateTimePicker.getDateTimeAndAllowEmptyTimes().
     */
    public LocalDateTime getNewDateTimeAndAllowEmptyTimes() {
        return getSource().getDateTimeAndAllowEmptyTimes();
    }

    /**
     * getOldDateTime, This returns the old LocalDateTime value from the DateTimePicker, as it would
     * have been reported by getSource().getDateTime(), before this change event occurred.
     *
     * For additional details, see DateTimePicker.getDateTime().
     */
    public LocalDateTime getOldDateTime() {
        // If there is no change event, then the old value is the same as the current value.
        LocalDate oldDateValue = datePicker.getDate();
        LocalTime oldTimeValue = timePicker.getTime();
        // If a change event exists, then the old value can be retrieved from the change event.
        oldDateValue = (dateChangeEvent != null) ? dateChangeEvent.getOldDate() : oldDateValue;
        oldTimeValue = (timeChangeEvent != null) ? timeChangeEvent.getOldTime() : oldTimeValue;
        // If either will value is null, then this function will return null.
        if (oldDateValue == null || oldTimeValue == null) {
            return null;
        }
        // Return the combination of the two values.
        return LocalDateTime.of(oldDateValue, oldTimeValue);
    }

    /**
     * getOldDateTimeAndAllowEmptyTimes, This returns the old LocalDateTime value from the
     * DateTimePicker, as it would have been reported by
     * getSource().getDateTimeAndAllowEmptyTimes(), before this change event occurred.
     *
     * For additional details, see DateTimePicker.getDateTimeAndAllowEmptyTimes().
     */
    public LocalDateTime getOldDateTimeAndAllowEmptyTimes() {
        // If there is no change event, then the old value is the same as the current value.
        LocalDate oldDateValue = datePicker.getDate();
        LocalTime oldTimeValue = timePicker.getTime();
        // If a change event exists, then the old value can be retrieved from the change event.
        oldDateValue = (dateChangeEvent != null) ? dateChangeEvent.getOldDate() : oldDateValue;
        oldTimeValue = (timeChangeEvent != null) ? timeChangeEvent.getOldTime() : oldTimeValue;
        // This function allows the old time value to be null, and be replaced with midnight.
        oldTimeValue = (oldTimeValue == null) ? LocalTime.MIDNIGHT : oldTimeValue;
        // If there was no old date value, then return null.
        if (oldDateValue == null) {
            return null;
        }
        // Return the combination of the two values.
        return LocalDateTime.of(oldDateValue, oldTimeValue);
    }
}
