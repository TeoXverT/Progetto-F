package com.github.lgooddatepicker.zinternaltools;

import java.awt.Color;

public class InternalConstants {
    static public Color colorEditableTextFieldBorder = new Color(122, 138, 153);
    static public Color colorNotEditableTextFieldBorder = new Color(184, 207, 229);
}
